var footHtml = ''; //foot inner HTML;
footHtml += '<div class="ui_update"> Last update: <strong><em></em></strong></div>';
footHtml += '<a href="#contents" class="btn_top"><i></i>top</a>';

$("footer").html(footHtml);