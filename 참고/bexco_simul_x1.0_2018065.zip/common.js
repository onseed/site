var browser; //디바이스 체크 분기

var aswUi = {	
		'deviceAgent' : function(){	
			var  
			ua  = navigator.userAgent,				
			support = $.support,
			ie, version;
			browser = $.browser;
			
			if ( !browser ) {//$.browser 지원이 안되면 객체로 생성?
				$.browser = browser = {};
			}
			
			//test 값 true,false 값 적용
			browser.local = (/^http:\/\//).test(location.href);
			browser.firefox = (/firefox/i).test(ua);
			browser.webkit = (/applewebkit/i).test(ua);
			browser.chrome = (/chrome/i).test(ua);
			browser.opera = (/opera/i).test(ua);
			browser.ios = (/ip(ad|hone|od)/i).test(ua);
			browser.android = (/android/i).test(ua);
			browser.safari = browser.webkit && !browser.chrome;				
			
			// ie 버전 체크. 결과값은 MSIE 7,7 ~10. ie11 : rv:11.0) like Gecko,,11.0				
			var ie = ua.match(/(?:msie ([0-9]+)|rv:([0-9\.]+)\) like gecko)/i);
			
			// 터치가능여부 체크
			support.touch = browser.ios || browser.android || (document.ontouchstart !== undefined && document.ontouchstart !== null);
			browser.mobile = support.touch && ( browser.ios || browser.android );						
			
			//os check
			browser.os = (navigator.appVersion).match(/(mac|win|linux)/i),
			browser.os = ( browser.os )? browser.os[1].toLowerCase() : '';
			
			// ios, android version check
			if ( browser.ios || browser.android ) {
				version = ua.match(/applewebkit\/([0-9.]+)/i);
				if ( version && version.length > 1 ) {
					browser.webkitversion = version[1];
				}
				if ( browser.ios ) {
					version = ua.match(/version\/([0-9.]+)/i);
					if ( version && version.length > 1 ) {
						browser.ios = version[1];
					}
				} else if ( browser.android ) {
					version = ua.match(/android ([0-9.]+)/i);
					if ( version && version.length > 1 ) {
						browser.android = parseInt(version[1].replace(/\./g, ''));
					}
				}
			}
			
			// ie version check
			if (ie) {
				browser.ie = ie = parseInt( ie[1] || ie[2] );
			}
			
			//Device Agent addClass
			function agentAddClass(){					
			    $(document.documentElement).addClass(browser.os)
		        .addClass(browser.chrome ? 'chrome' : browser.firefox ? 'firefox' : browser.opera ? 'opera' : browser.safari ? 'safari' : browser.ie ? 'ie ie'+browser.ie : '')
		        .addClass(browser.ie && 8 > browser.ie ? 'ie8' : '')
		        .addClass(browser.ios ? 'ios' : browser.android ? 'android' : '')
		        .addClass(browser.local ? 'local' : '')
				.addClass(browser.mobile ? 'mobile' : 'desktop');
			}
			agentAddClass();
			
			//스크린사이즈 체크	
			var sizeMode;
			function sizeCheck(){
				var width = document.documentElement.offsetWidth,					
				sizeMode = width > 900 ? ' pc2' : width > 768 ? ' pc1' : width > 413 ? ' mo2' : ' mo1';
				$(document.documentElement).removeClass("pc1").removeClass("pc2").removeClass("mo1").removeClass("mo2");
				document.documentElement.className += (sizeMode);	
			}
			sizeCheck();				
			
			$(window).resize(function(){
				sizeCheck();
				agentAddClass();
			});				
			//console.log("deviceAgent() : 디바이스 체크 분기");				
		},	
        'layerPopup' : function() {
        	var modalBgSet = ['modal_bg' , 0.3 , 600] //레이어팝업 설정: 클래스명(String), opacity(Number), ani Time(Number)

        	$.fn.extend({
        	    layerPopAw : function(opt) {
        	    	var modalBgClass= modalBgSet[0];
        	    	
        	        var defaults = {
        	                fullType : false, // true = only 전체메뉴 스타일
        	                maxW : 500,
        	                auto : false,
        	                mg : 15,//margin value
        	                ps : '' // default:'' = 'center', 'top'
        	            },
        	            opt = $.extend(defaults, opt);

        	        return this.each(function(){
        	            var $this       = $(this),
        	                $win        = $(window),
        	                $doc        = $(document),
        	                $body       = $('body'),
        	                $wrapper    = $('.wrap'),

        	                fullType    = opt.fullType,
        	                auto        = opt.auto,
        	                maxW        = opt.maxW,
        	                mg          = opt.mg,
        	                ps          = opt.ps,
        	                target      = $this.attr('id'),
        	                $btn        = $('[data-target="' + target + '"]'),

        	                $modal      = $('#' + target),
        	                $modal_h    = $modal.children('header'),
        	                $modal_c    = $modal.children('.cont'),
        	                $modal_f    = $modal.children('.modal_footer'),
        	                $modalBtn   = $modal.find('button, a'),

        	                modalBg     = '<div class=" '+modalBgClass+' "></div>',
        	                $modalBg    = $('.'+modalBgClass),

        	                mhH         = $modal_h.outerHeight(),
        	                mcH         = $modal_c.outerHeight(),
        	                mfH         = $modal_f.outerHeight(),

        	                winW        = $win.width(),
        	                layW        = Number(winW - 20),
        	                layH,
        	                nPs         = $(document).scrollTop(),
        	                wH;

        	            $this.data('ps', ps);

        	            var app = {
        	                show : function(target) {
        	                    $modal = $('#' + target);
        	                    if (!fullType) {//일반 레이어팝업일때
        	                        $modal.css({display : 'block',opacity : 0});
        	                        setTimeout(function() {
        	                            wH      = $win.height();
        	                            winW    = $win.width(),
        	                            layW    = Number(winW - (mg*2));
        	                            layH    = $modal.outerHeight();
        	                            
        	                            var _t      = ($this.data('ps') === 'top') ? 0 : (wH < layH) ? mg : '50%',
        	                                _w      = 'auto',   //($this.data('ps') === 'top') ? winW : layW,
        	                                _mw     = ($this.data('ps') === 'top') ? '' : maxW,
        	                                _l      = ($this.data('ps') === 'top') ? 0 : mg, //'50%'
        	                                _r      = ($this.data('ps') === 'top') ? 0 : mg, //'50%'
        	                                _ml     = 0,        //($this.data('ps') === 'top') ? 0 : (layW / 2) * -1,
        	                                _mt     = ($this.data('ps') === 'top') ? layH * -1 : (layH / 1.5) * -1,
        	                                _mt2    = ($this.data('ps') === 'top') ? 0 : (wH < layH) ? 0 : (layH / 2) * -1 ;
        	                            
        	                            $modal.css({//모달 css를 실시간으로
        	                                    width : _w,
        	                                    top : _t,
        	                                    left : _l,
        	                                    right : _r,
        	                                    marginLeft : _ml,
        	                                    marginTop : _mt,
        	                                    maxWidth : _mw
        	                                })
        	                                .stop().animate({
        	                                    opacity : 1,
        	                                    marginTop : _mt2
        	                                }, 200)
        	                                .addClass('lypopFocus').attr('tabindex', 0).focus();        	                            
        	                            //console.log("width :"+ _w + ", top : " + _t + ", left :"+ _l +", right : "+_r + ", marginLeft : "+ _ml + ", marginTop : " +_mt +", maxWidth : "+ _mw);
        	                            if ($this.data('ps') !== 'top') {
        	                                $(window).resize(function(){//리사이즈시
        	                                    var layH2   = $modal.outerHeight();
        	                                    (wH < layH || wH < (layH2 + mg*2)) ? app.overLayer(): '';
        	                                    if ($modal.outerWidth() >= maxW) {
        	                                        var maxW_l = ($win.width() - maxW) / 2;
        	                                        $modal.css({ left: maxW_l });
        	                                    } else {
        	                                        $modal.css({ left: _l });
        	                                    }
        	                                }).resize();
        	                            }
        	                        },35);
        	                        //if (!$('.'+modalBgClass).length) {//2중팝업을 위해 일단 주석처리함
        	                            $body.append(modalBg);
        	                            $modalBg = $('.'+modalBgClass);
        	                            $modalBg.stop().animate({ opacity : modalBgSet[1] }, modalBgSet[2]).on('click', function(){
       	                                    app.hide();
        	                            });
        	                        //}
        	                    }else{ //only 전체메뉴 스타일 (fullType일때)        	                       
        	                        nPs = $doc.scrollTop();
        	                        mg = 0
        	                        $body.stop().animate({scrollTop: 0},200, function(){
        	                            $modal.css({display: 'block'});        	
        	                            $modal.addClass('on');
        	                            $modal.stop().animate({left : 0},300, function(){
        	                                wH = $(window).height();
        	                               
        	                                $body.addClass('full_popup');
        	                                $wrapper.css({
        	                                    padding:'18px',
        	                                    'box-sizing':'border-box',
        	                                    overflow: 'hidden',
        	                                    position: 'absolute'
        	                                });
        	                                $body.css({ overflow: 'hidden' });
        	                                $modal.addClass('lypopFocus').attr('tabindex', 0).focus();        	                                
        	                            });        	                            
        	                           app.overLayer();        	                            
            	                        if (!$('.'+modalBgClass).length) {
            	                            $body.append(modalBg);
            	                            $modalBg = $('.'+modalBgClass);
            	                            $modalBg.stop().animate({ opacity : modalBgSet[1] }, modalBgSet[2]).on('click', function(){
           	                                    app.hide();
            	                            });
            	                        }
        	                        });
        	                    }
        	                    $modalBtn.off('click.layerPopClose').on('click.layerPopClose', function() {//닫기
        	                        ($(this).data('dismiss') === 'modal') ? app.hide() : '';
        	                    });
        	                },
        	                overLayer : function(){
        	                    wH  = $win.height();
        	                    mhH = $modal_h.outerHeight();
        	                    mfH = $modal_f.outerHeight();
        	                    $modal.css({
        	                        top : mg,
        	                        marginTop : 0
        	                    });
        	                    $modal_c.removeAttr('style').css({
        	                        height: wH - (mfH + mhH + (mg*2)), overflowY: 'scroll',
        	                        boxSizing : 'border-box'
        	                    });
        	                    $modal_f.css({ borderTop : '1px solid #d4d4d4 '})
        	                },
        	                hide : function() {
        	                    if (!fullType) {
        	                        $wrapper.css({
        	                            height : '',
        	                            overflow: ''
        	                        });
        	                        $modal.stop().animate({
        	                            opacity : 0,
        	                            marginTop : (layH / 1.5) * -1
        	                        }, 300, function(){
        	                            $modal.css({ display: 'none' }).removeAttr('tabindex').removeAttr('style');
        	                            $modal_c.removeAttr('style');
        	                        });
        	                        $modalBg = $('.'+modalBgClass).last();
        	                        $modalBg.stop().animate({
        	                            opacity : 0
        	                        }, 400, function(){
        	                            $modalBg.remove();
        	                            $modalBtn.removeClass('on hover');
        	                        });
        	                        $btn.focus();
        	                    } else { //only 전체메뉴 스타일 (fullType일때)
        	                        $('body').removeAttr('style');
        	                        $modal.animate({
        	                            left : '100%'
        	                        },200 , function(){
        	                            $body.removeClass('full_popup').stop().animate({
        	                                scrollTop: nPs
        	                            });
            	                        $modal.stop().animate({
            	                            opacity : 0,
            	                            marginTop : (layH / 1.5) * -1
            	                        }, 300, function(){
            	                            $modal.css({ display: 'none' }).removeAttr('tabindex').removeAttr('style');
            	                            $modal_c.removeAttr('style');
            	                        });
            	                        $modalBg = $('.'+modalBgClass);
            	                        $modalBg.stop().animate({
            	                            opacity : 0
            	                        }, 400, function(){
            	                            $modalBg.remove();
            	                            $modalBtn.removeClass('on');
            	                        });
        	                            $modal.css({ display: 'none' });
        	                            $wrapper.css({
        	                                    padding:'',                                    
        	                                    overflow: '',
        	                                    position: ''
        	                            });
        	                            $modal.removeClass('on');
        	                        });
        	                        $btn.focus();
        	                    }
        	                },
        	                imprison : function(){//탭키 이동을 위한 구문
        	                    var $modalFocus = $modal.find('a, input, button');
        	                    $modalFocus.eq(0).addClass('fst');
        	                    $modalFocus.eq(-1).addClass('end');
        	                    $modal.find('.lypopFocus, .fst').on('keydown',function(e){
        	                        if(e.shiftKey && e.keyCode == 9) {
        	                            e.preventDefault();
        	                            $modal.find('.end').focus();
        	                        }
        	                    });
        	                    $modal.find('.end').on('keydown',function(e){
        	                        if(!e.shiftKey && e.keyCode == 9) {
        	                            e.preventDefault();
        	                            $modal.find('.fst').focus();
        	                        }
        	                    });
        	                },
        	                eventHandler : function() {
        	                    if (auto) {
       	                            app.show(target);
       	                            app.imprison();
        	                    }        	                    
        	                    $btn.off('click.layerPopOpen').on('click.layerPopOpen', function(e) {
        	                        e.preventDefault();
        	                        target = $(this).data('target');
        	                        app.show(target);
        	                        app.imprison();
        	                    });
        	                }
        	            }
        	            app.eventHandler();
        	        });
        	    }
        	}); 
        	//console.log("layerPopup() : 레이어 팝업");	
        },		
		'imgDir' : function(){				
			$('.wrap img').each(function(){						
				var thisUrl = $(this).attr("src"),	
					changeUrl = imgDirCahnge + thisUrl;
				$(this).attr("src",changeUrl);
			});
			//
		},
		'init' : function(){
			//aswUi.imgDir(); //이미지 경로 변경
			aswUi.deviceAgent(); //에이젼트 체크
			aswUi.layerPopup(); //레이어팝업사용
			
		}
}
$(function(){
	aswUi.init();
	
	$(".topMenu.Menu").click(function(e){//메뉴열기
		$(".wrap").append("<div class='menu_bg'></div>");
		$(".rightMenuBox").stop().animate({"right":"5"},200,function(){
			$(".rightMenuBox").animate({"right":"-5"},100,function(){
				$(".rightMenuBox").animate({"right":"0"},200);
			});
		});

		$(".rightMenuBox .close, .menu_bg").click(function(){//메뉴닫기
			$(".rightMenuBox").stop().animate({"right":"-250px"},300);
			$(".menu_bg").remove();		
		});
		e.preventDefault();
	});//end	
	
});		

$(window).load(function(){
	$(".fade_bg").fadeOut("slow");
});
